## Welcome to my script graveyard

This was born out of negligence, but still this is the place where most of my scripts can be found!