import os
import sys
import tweepy


twitterASECRET
twitterATOKEN

twitterCAPIKEY
twitterCAPISEC