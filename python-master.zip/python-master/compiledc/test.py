import example

print(example.fact(5))
print(example.modulo(6,5))
