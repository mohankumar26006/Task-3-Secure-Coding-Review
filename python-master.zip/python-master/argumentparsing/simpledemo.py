import sys

if len(sys.argv) == 3:
	print("Good to go!")
else:
	print("Not enough arguments!")
