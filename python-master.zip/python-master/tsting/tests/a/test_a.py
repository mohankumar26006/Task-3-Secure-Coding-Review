from pytest import mark

@mark.a
def test_a():
    assert True