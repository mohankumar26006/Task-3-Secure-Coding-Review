#!/bin/bash
pkill python
