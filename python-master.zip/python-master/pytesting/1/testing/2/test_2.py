

class AwesomeTest:
    def test_2():
        assert True